self.__precacheManifest = (self.__precacheManifest || []).concat([
  {
    "revision": "4d67c00f1cdde0761f222b6454b750d0",
    "url": "/extensions/fleet-competitiveness/index.html"
  },
  {
    "revision": "44ae24a72448d3ce124d",
    "url": "/extensions/fleet-competitiveness/static/css/main.0c74f580.chunk.css"
  },
  {
    "revision": "657d54a51d20936c75e2",
    "url": "/extensions/fleet-competitiveness/static/js/2.86291ac3.chunk.js"
  },
  {
    "revision": "d891fcc30dfc707e593ab65e09f6fef9",
    "url": "/extensions/fleet-competitiveness/static/js/2.86291ac3.chunk.js.LICENSE.txt"
  },
  {
    "revision": "44ae24a72448d3ce124d",
    "url": "/extensions/fleet-competitiveness/static/js/main.d771cc3c.chunk.js"
  },
  {
    "revision": "9c4f054ec0d26eee753c",
    "url": "/extensions/fleet-competitiveness/static/js/runtime-main.db9c2b6a.js"
  },
  {
    "revision": "71cd086a2bf705f2cf5f1e90c064b9c6",
    "url": "/extensions/fleet-competitiveness/static/media/flags.71cd086a.jpg"
  },
  {
    "revision": "2f2bda7a1a43a5968aa3f81776b03c21",
    "url": "/extensions/fleet-competitiveness/static/media/logo.2f2bda7a.png"
  },
  {
    "revision": "37fe8322b169ddbdeabf75930e886ac6",
    "url": "/extensions/fleet-competitiveness/static/media/logo.37fe8322.png"
  },
  {
    "revision": "d320718ad0c819a92efefd5fb56a9e4d",
    "url": "/extensions/fleet-competitiveness/static/media/ltr.d320718a.jpg"
  },
  {
    "revision": "3e828842837bfa8b210caa82c9f5b4f5",
    "url": "/extensions/fleet-competitiveness/static/media/lui-icons.3e828842.ttf"
  },
  {
    "revision": "85a6c3d0e351dd3b0803468e26649303",
    "url": "/extensions/fleet-competitiveness/static/media/lui-icons.85a6c3d0.woff"
  },
  {
    "revision": "00c95aed31ffb5bece0c104d8ce6db28",
    "url": "/extensions/fleet-competitiveness/static/media/methodology.00c95aed.jpg"
  },
  {
    "revision": "acd20749d2c7180c2da4f3fb7d4e1a74",
    "url": "/extensions/fleet-competitiveness/static/media/purchasing.acd20749.jpg"
  },
  {
    "revision": "d4d2222e570f715d71af8aa8b33febe2",
    "url": "/extensions/fleet-competitiveness/static/media/section1.d4d2222e.jpg"
  },
  {
    "revision": "b4f1bcf190a6d7901caec6483aebd91c",
    "url": "/extensions/fleet-competitiveness/static/media/stelvio.b4f1bcf1.jpg"
  }
]);